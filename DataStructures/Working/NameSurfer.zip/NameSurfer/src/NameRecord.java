
import java.util.ArrayList;
import java.util.Scanner;

/*  Student information for assignment:
 *
 *  On my honor, Ahmed AlJehairan, this programming assignment is my own work
 *  and I have not provided this code to any other student.
 *
 *  UTEID: aa29665
 *  email address: ahmed24633@gmail.com
 *  Grader name: Yuanzhong
 *  Number of slip days I am using:0
 */
public class NameRecord {
    //instance vars

    private String name="";
    private ArrayList<Integer> ranks = new ArrayList();
    private Scanner lineScanner;
    private int decade;
    private final static int[] DECADES = new int[]{1900, 1910, 1920, 
        1930, 1940, 1950, 1960, 
        1970, 1980, 1990, 2000};
    
    
    //constructor
    //pre: line!=null
    public NameRecord(String line) {
        try{
        lineScanner = new Scanner(line);
        while (!lineScanner.hasNextInt())
                name+=lineScanner.next();
//        System.out.println(name);
        this.storeRanks();
        lineScanner.close();
        }
        catch (NullPointerException e){
                    System.out.println("String is null");
        
    }

    }

    public String getName() {
        return this.name;
    }

    private void storeRanks() {
        if (ranks.isEmpty()) {
            while (lineScanner.hasNext()) {
                ranks.add(lineScanner.nextInt());
            }
        }
    }
    

    public int getRank(int decade) {
        return ranks.get(decade);
    }

    public int bestDecade() {
        int min = 1000;
        for (int i = 0; i < ranks.size(); i++) {

            if (ranks.get(i) != 0 && ranks.get(i) < min) {
                min = ranks.get(i);
                decade = i;
            }
        }
        return DECADES[decade];
    }

    public int countRanks() {
        int count = 0;
        for (int decade : ranks) {
            if (decade > 0) {
                count++;
            }
        }
        return count;
    }

    public boolean rankedInAll() {
        if (this.countRanks() == 11) {
            return true;
        } else {
            return false;
        }
    }

    public boolean rankedOnlyOnce() {
        if (this.countRanks() == 1) {
            return true;
        } else {
            return false;
        }
    }

    public boolean isImproving() {
        int index = 0;
//        int index = this.cleanClutter(0);
            boolean isDecreasing = this.ranks.get(index) == 0
                || this.ranks.get(index) > this.ranks.get(index + 1);

        int min = this.ranks.get(index) == 0
                ? 1000 : Math.min(1000, this.ranks.get(index));
//   System.out.print(min);
        index++;

//        System.out.print(isDecreasing);
//         System.out.print(index);
        while (isDecreasing && index < this.ranks.size()) {

            isDecreasing = (this.ranks.get(index) != 0
                    && min > Math.min(min, this.ranks.get(index)));
//            System.out.print(this.ranks.get(index));
            min = Math.min(min, this.ranks.get(index));
            index++;
        }
        return isDecreasing;
    }

    public boolean isWorsening() {
        int backIndex = this.ranks.size() - 1;


        boolean isIncreasing = this.ranks.get(backIndex) == 0
                || this.ranks.get(backIndex) > this.ranks.get(backIndex - 1);

        int min = this.ranks.get(backIndex) == 0
                ? 1000 : Math.min(1000, this.ranks.get(backIndex));

//        System.out.print(min);

        backIndex--;

//        System.out.print(isIncreasing);
//        System.out.print(backIndex);
        while (isIncreasing && backIndex > 0) {
//            System.out.print(min);
            isIncreasing = (this.ranks.get(backIndex) != 0
                    && min > Math.min(min, this.ranks.get(backIndex)));
//            System.out.print(this.ranks.get(backIndex));
            min = Math.min(min, this.ranks.get(backIndex));
            backIndex--;
        }

        return isIncreasing;
    }
    public boolean isDoubling(){
        boolean isMoore = true; //as in Moore's law
        for (int i=0;isMoore&&i+1<this.ranks.size();i++)
            isMoore=this.getRank(i+1)/this.getRank(i)==2;
        return isMoore;
        
    }
}
