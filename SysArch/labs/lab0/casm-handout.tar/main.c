// Main program

#include <stdio.h>
#include <stdlib.h>


// Execution starts here.

int main( int   argc,       // Number of arguments
          char *argv[],     // Pointer to array of characters
          char *env [] )    // Pointer to array of characters
{
  int in, ans;              // Space for integers "in" and "ans"

  if ( argc != 2 ) {
    printf("argc value is not 2, but %d.\n", argc );
    exit ( argc );
  }

  in = atoi( argv[ 1 ] );   // Convert ASCII into an integer

  printf( "argv[ 1 ] is: %d.\n", in );  // Print the conversion result

  ans = in;
  // ans = times_7        ( in );
  // ans = is_ascii       ( in );
  // ans = is_character   ( in );
  // ans = remainder_by_8 ( in );
  // ans = negation       ( in );
  // ans = bit_count      ( in );
  // ans = overflow_3     ( in );
  // ans = bit_count      ( in );

  // Test harness -- put your testing code here

  // printf("Test is working:  %d\n.", <test expression>);
  // End test harness

  printf( "ans is: %d.\n", ans );
  exit ( 0 );
}
